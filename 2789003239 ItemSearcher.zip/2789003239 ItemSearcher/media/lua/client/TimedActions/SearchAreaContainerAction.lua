local collectionUtil = require("PZISCollectionUtils");
local Set = collectionUtil.Set;

SearchAreaContainerAction = {}

local searchTarget = nil;
local dist = 999;
local foundObjectPosition = nil;

local print = function(...)
    print("[ItemSearcher (SearchAreaContainerAction)] - ", ...);
end

SearchAreaContainerAction.getDistanceBetween = function(x1, y1, x2, y2)
    local dx = x1 - x2;
    local dy = y1 - y2;

    return math.sqrt(math.pow(dx, 2) + math.pow(dy, 2));
end

convertArrayList = function(arrayList)
    local itemTable = {};

    for i = 1, arrayList:size() do
        itemTable[i] = arrayList:get(i - 1);
    end

    return itemTable;
end
SearchAreaContainerAction.findItem = function(gameItemContainer)
    local displayNameSearch = searchTarget.displayName;
    local nameSearch = searchTarget.name;
    local fullTypeSearch = searchTarget.fullType;

   
    local items = gameItemContainer:getItems();
    local itemsCount = items:size();

    local playerPosition = getSpecificPlayer(0):getCurrentSquare();

    if itemsCount > 0 then
        for x = 0, itemsCount - 1 do
            local item = items:get(x);

            local displayName = item:getDisplayName();
            local name = item:getName();
            local fullType = item:getFullType();

            if displayNameSearch == displayName then
                print("Display name hit against search: " .. displayNameSearch);
                print("Hit item's name: " .. name .. ", fullType: " .. fullType);
                print("Search items name: " .. nameSearch .. ", fullType: " .. fullTypeSearch);
            end

            if displayNameSearch == displayName and (nameSearch == name or fullTypeSearch == fullType) then
                -- Ask the InventoryContainer for the count, not including items that can be drained, recursing through inventory container items
                local gameItemContainerPosition = gameItemContainer:getSourceGrid();
                local tempDist = SearchAreaContainerAction.getDistanceBetween(playerPosition:getX(),playerPosition:getY(), gameItemContainerPosition:getX(), gameItemContainerPosition:getY());
                if tempDist < dist then
                    dist = tempDist;
                    foundObjectPosition = gameItemContainerPosition;
                end
                return gameItemContainer:getNumberOfItem(fullType, false, true);
            end
        end
    end

    return 0;
end


SearchAreaContainerAction.findItemCategory = function(gameItemContainer)
    local searchCategory = searchTarget;

   
    local items = gameItemContainer:getItems();
    local itemsCount = items:size();

	local itemsSameCategory = {}
    if itemsCount > 0 then
        for x = 0, itemsCount - 1 do
            local item = items:get(x);

            local category = item:getCategory();

            if searchCategory == category then
                -- Ask the InventoryContainer for the count, not including items that can be drained, recursing through inventory container items
                --return item
				table.insert(itemsSameCategory, item);
            end
        end
    end

    if #itemsSameCategory==0 then return nil;
	else return itemsSameCategory;
	end
end

SearchAreaContainerAction.find = function(searchTargetLocal, location, maxRangeArea)
    searchTarget = searchTargetLocal;
    dist = 999;
    foundObjectPosition = nil;
        -- Define the name of the item to search for
    local itemName = searchTarget.name;


    --local playerPosition = getSpecificPlayer(0):getCurrentSquare();
    local playerx = location:getX();
    local playery = location:getY();
    local playerz = location:getZ();

    local worldCell = getWorld():getCell();

    -- search for containers within 10 squares of the player on the same z level
    local xrange = maxRangeArea;
    local yrange = maxRangeArea;
    local containerObjects = {};

    local amount = 0;

    for x=(playerx-xrange), (playerx+xrange) do
        for y=(playery-yrange), (playery+yrange) do
            local containerSearchSquare = worldCell:getGridSquare(x,y,playerz);
            if(containerSearchSquare ~= nil) then
                --print('>>> Container search square not nil, checking...');
                local items = containerSearchSquare:getObjects();

                for k,v in ipairs(convertArrayList(items)) do
                    local possibleContainerObject = v;

                    if possibleContainerObject:getContainer() ~= nil then
                        local objectContainer = possibleContainerObject:getContainer();

                        if objectContainer ~= nil then
                            local result = SearchAreaContainerAction.findItem(objectContainer);
                            amount = amount + result;
                        end  
                    end   
                end
            end
        end
    end

    return amount, math.floor(dist+0.5), foundObjectPosition;
    -- If the loop has completed, the item was not found
    --print(itemName .. " not found in any unexplored container in the building.")

end



SearchAreaContainerAction.findCategory = function(searchTargetLocal, maxRangeArea)
    searchTarget = searchTargetLocal;
    dist = 999;
    foundObjectPosition = nil;
        -- Define the name of the item to search for
    local itemName = searchTarget.name;


    local playerPosition = getSpecificPlayer(0):getCurrentSquare();
    local playerx = playerPosition:getX();
    local playery = playerPosition:getY();
    local playerz = playerPosition:getZ();

    local worldCell = getWorld():getCell();

    -- search for containers within 10 squares of the player on the same z level
    local xrange = maxRangeArea;
    local yrange = maxRangeArea;
    local containerObjects = {};

    local amount = 0;
	
	local itemsTable = {};
	local avoidDuplicates = {};
	avoidDuplicates = Set:new();
	local atleastOne = false;

    for x=(playerx-xrange), (playerx+xrange) do
        for y=(playery-yrange), (playery+yrange) do
            local containerSearchSquare = worldCell:getGridSquare(x,y,playerz);
            if(containerSearchSquare ~= nil) then
                --print('>>> Container search square not nil, checking...');
                local items = containerSearchSquare:getObjects();

                for k,v in ipairs(convertArrayList(items)) do
                    local possibleContainerObject = v;

                    if possibleContainerObject:getContainer() ~= nil then
                        local objectContainer = possibleContainerObject:getContainer();

                        if objectContainer ~= nil then
                            local itemsMatch = SearchAreaContainerAction.findItemCategory(objectContainer);
							
							if itemsMatch ~= nil then
								for _, item in pairs(itemsMatch) do
									local nameItem = item:getDisplayName();
									if not avoidDuplicates:contains(nameItem) then
										avoidDuplicates:add(nameItem);
										table.insert(itemsTable,item);
										atleastOne=true;
									end
								end
								--table.insert(itemsTable,item:getID(),item);
							end
                            
                        end  
                    end   
                end
            end
        end
    end
	
	--if #itemsTable == 0 then
	if atleastOne == false then
		return nil;
	end
	
	--convertArrayList(itemsSet);
	
    --return itemsTable;
	
	local items = {};
	local itemsByDisplay = {};
	itemsByDisplay = ITEMSEARCH_PERSISTENT_DATA.itemsByDisplayName;
	for _, value in pairs(itemsTable) do
		local e = itemsByDisplay[value:getDisplayName()][1];		
		table.insert(items, e);
	end
	
	return items;
    -- If the loop has completed, the item was not found
    --print(itemName .. " not found in any unexplored container in the building.")

end


SearchAreaContainerAction.findAll = function(maxRangeArea)
    dist = 999;
    foundObjectPosition = nil;


    local playerPosition = getSpecificPlayer(0):getCurrentSquare();
    local playerx = playerPosition:getX();
    local playery = playerPosition:getY();
    local playerz = playerPosition:getZ();

    local worldCell = getWorld():getCell();

    -- search for containers within 10 squares of the player on the same z level
    local xrange = maxRangeArea;
    local yrange = maxRangeArea;
    local containerObjects = {};

    local amount = 0;
	
	local itemsTable = {};
	local avoidDuplicates = {};
	avoidDuplicates = Set:new();
	local atleastOne = false;

    for x=(playerx-xrange), (playerx+xrange) do
        for y=(playery-yrange), (playery+yrange) do
            local containerSearchSquare = worldCell:getGridSquare(x,y,playerz);
            if(containerSearchSquare ~= nil) then
                --print('>>> Container search square not nil, checking...');
                local items = containerSearchSquare:getObjects();

                for k,v in ipairs(convertArrayList(items)) do
                    local possibleContainerObject = v;

                    if possibleContainerObject:getContainer() ~= nil then
                        local objectContainer = possibleContainerObject:getContainer();

                        if objectContainer ~= nil then
                            local itemsMatch = convertArrayList(objectContainer:getItems());
							
							if itemsMatch ~= nil then
								for _, item in pairs(itemsMatch) do
									local nameItem = item:getDisplayName();
									local displayCat = item:getDisplayCategory();
									if displayCat~="Junk" and displayCat~="Appearance" and not avoidDuplicates:contains(nameItem) then
										avoidDuplicates:add(nameItem);
										table.insert(itemsTable,item);
										atleastOne=true;
									end 
								end
								--table.insert(itemsTable,item:getID(),item);
							end
                            
                        end  
                    end   
                end
            end
        end
    end
	
	--if #itemsTable == 0 then
	if atleastOne == false then
		return nil;
	end
	
	--convertArrayList(itemsSet);
	
    --return itemsTable;
	
	local items = {};
	local itemsByDisplay = {};
	itemsByDisplay = ITEMSEARCH_PERSISTENT_DATA.itemsByDisplayName;
	for _, value in pairs(itemsTable) do
		local matches =itemsByDisplay[value:getDisplayName()];
		if matches ~= nil then			
			local e = matches[1];		
			table.insert(items, e);
		end
	end
	
	return items;
    -- If the loop has completed, the item was not found
    --print(itemName .. " not found in any unexplored container in the building.")

end

