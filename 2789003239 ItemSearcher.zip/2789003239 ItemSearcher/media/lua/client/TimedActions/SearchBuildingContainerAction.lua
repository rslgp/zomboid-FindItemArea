SearchBuildingContainerAction = {}

local searchTarget = nil;

local print = function(...)
    print("[ItemSearcher (SearchBuildingContainerAction)] - ", ...);
end

SearchBuildingContainerAction.getDistanceBetween = function(x1, y1, x2, y2)
    local dx = x1 - x2;
    local dy = y1 - y2;

    return math.sqrt(math.pow(dx, 2) + math.pow(dy, 2));
end

convertArrayList = function(arrayList)
    local itemTable = {};

    for i = 1, arrayList:size() do
        itemTable[i] = arrayList:get(i - 1);
    end

    return itemTable;
end
SearchBuildingContainerAction.findItem = function(gameItemContainer)
    local displayNameSearch = searchTarget.displayName;
    local nameSearch = searchTarget.name;
    local fullTypeSearch = searchTarget.fullType;

    local items = gameItemContainer:getItems();
    local itemsCount = items:size();

    if itemsCount > 0 then
        for x = 0, itemsCount - 1 do
            local item = items:get(x);

            local displayName = item:getDisplayName();
            local name = item:getName();
            local fullType = item:getFullType();

            if displayNameSearch == displayName then
                print("Display name hit against search: " .. displayNameSearch);
                print("Hit item's name: " .. name .. ", fullType: " .. fullType);
                print("Search items name: " .. nameSearch .. ", fullType: " .. fullTypeSearch);
            end

            if displayNameSearch == displayName and (nameSearch == name or fullTypeSearch == fullType) then
                -- Ask the InventoryContainer for the count, not including items that can be drained, recursing through inventory container items
                return gameItemContainer:getNumberOfItem(fullType, false, true);
            end
        end
    else
        return 0;
    end

    return 0;
end

SearchBuildingContainerAction.findRoomContainers = function(room)
    local squares = room:getIsoRoom():getSquares();
    --local roomDef = room:getRoomDef();

    local squareCount = squares:size();

    local amount = 0;

    for i = 0, squareCount - 1 do
        local square = squares:get(i);

        local objectsScene = square:getObjects();

        for objInd = 0, objectsScene:size() - 1 do
            local sceneObj = objectsScene:get(objInd);
            local objectContainer = sceneObj:getContainer();

            if objectContainer ~= nil then
                local result = SearchBuildingContainerAction.findItem(objectContainer);
                amount = amount + result;
            end            
        end
    end

    return amount;
end

SearchBuildingContainerAction.find = function(searchTargetLocal, location)
    searchTarget = searchTargetLocal;
        -- Define the name of the item to search for
    local itemName = searchTarget.name;

    -- Get the player's current location
    --local player = getPlayer()
    --local playerLocation = player:getCurrentLocation()

    -- Get the building that the player is in
    local building = location:getBuilding():getDef();

    -- Get all the rooms in the building
    local rooms = building:getRooms();

    local displayNameSearch = searchTarget.displayName;
    local nameSearch = searchTarget.name;
    local fullTypeSearch = searchTarget.fullType;
    local amount = 0;
    -- Search the rooms for the item
    for _, room in ipairs(convertArrayList(rooms)) do
        local result = SearchBuildingContainerAction.findRoomContainers(room);
        amount = amount + result;
    end

    return amount;
    -- If the loop has completed, the item was not found
    --print(itemName .. " not found in any unexplored container in the building.")

end
